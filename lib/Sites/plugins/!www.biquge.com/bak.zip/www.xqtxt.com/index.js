module.exports = {
    "host":"www.xqtxt.com",
    "match":[
        "www.xqtxt.com"
    ],
    "charset":"utf8",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}