module.exports = {
    "host":"www.ldzw.com",
    "match":[
        "www.ldzw.com"
    ],
    "charset":"utf8",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}