module.exports = {
    "host":"www.xxbiquge.com",
    "match":[
        "www.xxbiquge.com"
    ],
    "charset":"utf8",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}