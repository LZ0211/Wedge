module.exports = {
    "host":"www.81zw.com",
    "match":[
        "www.81zw.com"
    ],
    "charset":"gbk",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}