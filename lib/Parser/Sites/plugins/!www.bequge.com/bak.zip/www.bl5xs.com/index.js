module.exports = {
    "host":"www.bl5xs.com",
    "match":[
        "www.bl5xs.com"
    ],
    "charset":"gbk",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}