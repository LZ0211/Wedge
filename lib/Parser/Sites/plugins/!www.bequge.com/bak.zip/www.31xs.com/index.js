module.exports = {
    "host":"www.31xs.com",
    "match":[
        "www.31xs.com"
    ],
    "charset":"gbk",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}