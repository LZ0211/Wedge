module.exports = {
    "host":"www.qu.la",
    "match":[
        "www.qu.la"
    ],
    "charset":"gbk",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}