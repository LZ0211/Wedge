module.exports = {
    "host":"www.biquge.cm",
    "match":[
        "www.biquge.cm"
    ],
    "charset":"gbk",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}