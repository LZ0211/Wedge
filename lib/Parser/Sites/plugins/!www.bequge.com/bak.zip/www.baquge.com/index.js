module.exports = {
    "host":"www.baquge.com",
    "match":[
        "www.baquge.com"
    ],
    "charset":"gbk",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}