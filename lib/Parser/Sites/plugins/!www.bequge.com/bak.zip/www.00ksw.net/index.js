module.exports = {
    "host":"www.00ksw.net",
    "match":[
        "www.00ksw.net"
    ],
    "charset":"gbk",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}