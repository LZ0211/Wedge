module.exports = {
    "host":"www.ranwen.net",
    "match":[
        "www.ranwen.net"
    ],
    "charset":"gbk",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}