module.exports = {
    "host":"www.qidian.com",
    "match":[
        "www.qidian.com",
        "read.qidian.com",
        "book.qidian.com"
    ],
    "charset":"utf8",
    "selector":require("./selector"),
    "replacer":require("./replacer")
}